import numpy as np
import cv2
from pylepton import Lepton

with Lepton() as l:
    while 1:
        a,_ = l.capture(log_time=True,debug_print=False)
        # print(a)
        cv2.normalize(a, a, 0, 65535, cv2.NORM_MINMAX) # extend contrast
        np.right_shift(a, 8, a) # fit data into 8 bits
#         cv2.show(f'output{i}.jpg', np.uint8(a)) # write it!
        image=np.uint8(a)
        heatmap=cv2.applyColorMap(image,cv2.COLORMAP_JET)
        image=cv2.resize(heatmap,(560,420),interpolation=cv2.INTER_NEAREST)
        cv2.imshow('123',image)
        cv2.waitKey(1)
        
        